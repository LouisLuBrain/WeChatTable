self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5d431081ec5ed0843c77e0c81f874ecb",
    "url": "./index.html"
  },
  {
    "revision": "226819d214161c9abcd9",
    "url": "./static/css/main.125bf553.chunk.css"
  },
  {
    "revision": "8d07ab6b7609df4f6a52",
    "url": "./static/js/2.16eda09d.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.16eda09d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "226819d214161c9abcd9",
    "url": "./static/js/main.9306a4e6.chunk.js"
  },
  {
    "revision": "27fa27c7c90767f39ad7",
    "url": "./static/js/runtime-main.b381f755.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "./static/media/logo.5d5d9eef.svg"
  }
]);